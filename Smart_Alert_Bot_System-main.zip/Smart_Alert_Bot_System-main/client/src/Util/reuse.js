// Account
{/* <div className="form-group">
                    <label htmlFor="fName">First Name</label>
                    <input type="text" className={formData.fName ? 'active': ''} name="fName" id="fName" value={formData.fName} onChange={changeHandler} />
                </div> */}

                // <div className="form-group">
                //     <label htmlFor="lName">Last Name</label>
                //     <input type="text" className={formData.lName ? 'active': ''} name="lName" id="lName" value={formData.lName} onChange={changeHandler} />
                // </div>

                
        //     <div className="form-group">
        //     <label htmlFor="email">Email</label>
        //     <input type="email" className={formData.email ? 'active': ''} name="email" id="email" autoComplete='off'  value={formData.email} onChange={changeHandler} />
        // </div>

        // <div className="form-group">
        //         <label htmlFor="password">Password</label>
        //         <input type="password" className={formData.password ? 'active': ''} name="password" id="password" value={formData.password} onChange={changeHandler} />
        //     </div>

// Personal


{/* <div className="form-group">
                <label htmlFor="cno">Consumer Number</label>
                <input type="number" className={formData.cno ? 'active': ''} name="cno" id="cno" value={cno} onChange={changeHandler} />
            </div> */}

{/* <div className="form-group">
                <label htmlFor="zone">Zone</label>
                <select className={formData.zone ? 'active': ''} name="zone" id="zone" value={formData.zone} onChange={changeHandler}>
                    <option hidden value>Select a zone</option>
                    <option value="Tiruvottiyur">Tiruvottiyur</option>
                    <option value="Anna Nagar">Anna Nagar</option>
                    <option value="Chengalpattu">Chengalpattu</option>
                    <option value="Valasaravakkam">Valasaravakkam</option>
                </select>
            </div> */}

            // {
            //     selectedZone && 
            //     <div className='form-group'>
            //         <label htmlFor="area">Area</label>
            //         <select className={formData.area ? 'active': ''}  name="area" id="area"  value={formData.area} onChange={changeHandler}>
            //             <option hidden value>Select an area</option>
            //         {
            //             zones[selectedZone].map((area, index) => {
            //                 return <option key={index} value={area}>{area}</option>
            //             })
            //         }
            //         </select>                    
            //     </div>
            // }