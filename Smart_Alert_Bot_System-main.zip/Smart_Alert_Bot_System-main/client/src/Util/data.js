export const formDetails = {
    "fName": "",
    "lName": "",
    "email": "",
    "password": "",
    "mno": "",
    "zone": "",
    "area": ""
};

export const zones = ["Tiruvottiyur", "Anna Nagar", "Chrompet", "Valasaravakkam"];

export const areas = {
    "Tiruvottiyur": ["Tiruvottiyur", "V.O.C Nagar", "Manali", "Wimco Nagar"],
    "Anna Nagar": ["Anna Nagar", "Villivakkam", "Padi", "Tirumangalam"],
    "Chrompet": ["Chrompet", "Pallavaram", "Tambaram Santorium", "Tambaram"],
    "Valasaravakkam": ["Valasaravakkam", "K K Nagar", "Porur", "Ramapuram"],
};

