import { Routes, Route } from "react-router-dom"

import "./index.css";

import Root from "./components";

const App = () => {
    return (
        <div className="App">
            <Root />
        </div>
    );
}

export default App;
