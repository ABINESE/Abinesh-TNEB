### Creative And Innovative Project
1. User saying they don't have power (eg no power in my area, we don't have power supply from the morning etc)
2. User saying they don't have power beoz of some reason like short circuit etc..
3. User saying low voltage problem
4. User requesting for power cut in case of emergency

keywords:
[
    'do not have power', 'do not have electricity', 'do not have current', 'do not have power supply', "don't have power", "don't have electricity", "don't have current", "don't have power supply", "didn't have power", "didn't have electricity", "didn't have current", "didn't have power supply", 'did not have power', 'did not have electricity', 'did not have current', 'did not have power supply', 'dont have power', 'dont have electricity', 'dont have current', 'dont have power supply', 'didnt have power', 'didnt have electricity', 'didnt have current', 'didnt have power supply', 'no power', 'no electricity', 'no current', 'no power supply', "doesn't have power", "doesn't have electricity", "doesn't have current", "doesn't have power supply", 'does not have power', 'does not have electricity', 'does not have current', 'does not have power supply', 'doesnt have power', 'doesnt have electricity', 'doesnt have current', 'doesnt have power supply', "power shortage", "power cut"
]

[
    "transformer burst", "trees fall on power line", "power line cuts due to heavy rain", "heavy load vehicles cuts the power line"
]

[
    "low voltage", "voltage fluctutation", "voltage drop"
]

[
    "cut power", "cut the power", "cut power supply", "cut the power supply", "cut electricity supply", "cut the electricity supply", "cut current supply", "cut the current supply", 
    "stop power", "stop the power", "stop power supply", "stop the power supply", "stop electricity supply", "stop the electricity supply", "stop current supply", "stop the current supply", 
]